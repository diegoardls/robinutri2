<?php
// Configuración para XAMPP
define('DB_HOST', 'localhost');
define('DB_NAME', 'robinutri');
define('DB_USER', 'root');
define('DB_PASS', '');  // Password vacío por defecto en XAMPP
define('DB_CHARSET', 'utf8mb4');
?>