<?php
require_once __DIR__ . '/../models/Database.php';
require_once __DIR__ . '/../models/ChatModel.php';
require_once __DIR__ . '/../models/ProfileModel.php';

class ChatController {
    private $chatModel;
    private $profileModel;
    private $db;

    public function __construct() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        $this->chatModel = new ChatModel();
        $this->profileModel = new ProfileModel();
    }
    public function index() {
        // ⭐⭐ VERIFICAR SI SE SOLICITA NUEVO CHAT
        $nuevoChat = $_GET['nuevo_chat'] ?? false;
        $perfilIdParam = $_GET['perfil_id'] ?? null;
        
        if ($nuevoChat && $perfilIdParam && isset($_SESSION['usuario_id'])) {
            // Crear nuevo chat forzadamente
            $chatId = $this->chatModel->createChat($perfilIdParam);
            if ($chatId) {
                // Redirigir al nuevo chat
                header('Location: /robinutri/index.php/chat?perfil_id=' . $perfilIdParam);
                exit;
            }
        }
        
        // ⭐⭐ VERIFICAR SI VIENE UN PERFIL ESPECÍFICO (tu código actual)
        if ($perfilIdParam && isset($_SESSION['usuario_id'])) {
            // Usar directamente el perfil de la URL
            $perfil = $this->profileModel->getById($perfilIdParam);
            if ($perfil) {
                $this->mostrarChatPrincipal($perfilIdParam);
                return;
            }
        }
        
        // Si no, continuar normal
        $this->mostrarChatPrincipal();
    }
    private function mostrarChatPrincipal($perfilIdForzado = null) {
        $usuarioLogueado = isset($_SESSION['usuario_id']);
        
        // Obtener perfiles
        $perfiles = $usuarioLogueado ? $this->profileModel->getAll() : [];
        
        $perfilActivo = null;
        $chatActivo = null;
        $mensajes = [];

        if ($usuarioLogueado && !empty($perfiles)) {
            // Determinar perfil activo
            if ($perfilIdForzado) {
                foreach ($perfiles as $perfil) {
                    if ($perfil['id'] == $perfilIdForzado) {
                        $perfilActivo = $perfil;
                        break;
                    }
                }
            }
            
            if (!$perfilActivo) {
                $perfilActivo = $perfiles[0];
            }
            
            // ⭐⭐ GARANTIZAR QUE EXISTE UN CHAT PARA ESTE PERFIL
            $chats = $this->chatModel->getChatsByProfile($perfilActivo['id']);
            
            if (empty($chats)) {
                // CREAR CHAT EN LA BASE DE DATOS
                $chatId = $this->chatModel->createChat($perfilActivo['id']);
                
                if ($chatId) {
                    // Chat creado exitosamente en BD
                    $chatActivo = $this->chatModel->getChatById($chatId);
                    
                    // ⭐⭐ CREAR MENSAJE DE BIENVENIDA AUTOMÁTICO
                    $mensajeBienvenida = "¡Hola! Soy RobiNutri. Estoy aquí para ayudarte con la nutrición de " . $perfilActivo['nombre'] . ".";
                    $this->chatModel->saveMessage($chatId, $mensajeBienvenida, 'bot');
                    
                } else {
                    // Error creando chat
                    echo "<!-- ERROR: No se pudo crear el chat -->";
                }
            } else {
                // Usar chat existente
                $chatActivo = $chats[0];
            }
            
            // Cargar mensajes si hay chat activo
            if ($chatActivo) {
                $mensajes = $this->chatModel->getMessages($chatActivo['id']);
            }
            
        } else {
            // Modo invitado
            $perfilActivo = ['nombre' => 'Invitado', 'edad' => '', 'id' => 0];
        }

        $datosVista = [
            'usuarioLogueado' => $usuarioLogueado,
            'perfilActivo' => $perfilActivo,
            'chatActivo' => $chatActivo,
            'mensajes' => $mensajes,
            'perfiles' => $perfiles
        ];
        
        require_once __DIR__ . '/../views/chat/index.php';
    }
    public function sendMessage() {
        header('Content-Type: application/json');
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $chatId = $_POST['chat_id'] ?? null;
            $mensaje = trim($_POST['mensaje'] ?? '');
            
            if ($chatId && !empty($mensaje)) {
                // Guardar mensaje del usuario
                $this->chatModel->saveMessage($chatId, $mensaje, 'user');
                
                // Generar respuesta inteligente del bot
                $respuestaBot = $this->generarRespuestaInteligente($mensaje);
                
                // Guardar respuesta del bot
                $this->chatModel->saveMessage($chatId, $respuestaBot, 'bot');
                
                echo json_encode([
                    'success' => true,
                    'bot_response' => $respuestaBot
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Mensaje vacío o chat no especificado'
                ]);
            }
        }
    }
    public function loadMessages() {
        header('Content-Type: application/json');
        
        $chatId = $_GET['chat_id'] ?? null;
        
        if ($chatId) {
            $mensajes = $this->chatModel->getMessages($chatId);
            
            echo json_encode([
                'success' => true,
                'mensajes' => $mensajes
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Chat no especificado'
            ]);
        }
    }
    public function verChatsPorPerfil() {
        header('Content-Type: application/json');
        
        if (!isset($_SESSION['usuario_id'])) {
            echo json_encode(['success' => false, 'message' => 'No logueado']);
            return;
        }
        
        $perfilId = $_GET['perfil_id'] ?? null;
        
        if ($perfilId) {
            $chats = $this->chatModel->getChatsByProfile($perfilId);
            echo json_encode([
                'success' => true,
                'chats' => $chats,
                'total' => count($chats)
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Perfil no especificado']);
        }
    }
    public function getChatsUsuario() {
        header('Content-Type: application/json');
        
        if (!isset($_SESSION['usuario_id'])) {
            echo json_encode(['success' => false, 'message' => 'No logueado']);
            exit;
        }
        // ⭐⭐ OBTENER EL PERFIL ESPECÍFICO SI SE SOLICITA
        $perfilIdFiltro = $_GET['perfil_id'] ?? null;

        // ⭐⭐ SIN DEBUG, SIN COMENTARIOS
        $perfiles = $this->profileModel->getAll();
        $todosLosChats = [];
        
        foreach ($perfiles as $perfil) {
            $chatsDelPerfil = $this->chatModel->getChatsByProfile($perfil['id']);
            foreach ($chatsDelPerfil as $chat) {
                $chat['perfil_nombre'] = $perfil['nombre'];
                $chat['perfil_id'] = $perfil['id']; // ⭐⭐ AGREGAR ID DEL PERFIL

                $todosLosChats[] = $chat;
            }
        }
        
        usort($todosLosChats, function($a, $b) {
            return strtotime($b['fecha_ultimo_mensaje']) - strtotime($a['fecha_ultimo_mensaje']);
        });
        
        // ⭐⭐ SOLO JSON, NADA MÁS
        echo json_encode([
            'success' => true, 
            'chats' => $todosLosChats
        ]);
        exit;
    }
    public function createChat() {
        header('Content-Type: application/json');
        
        if (!isset($_SESSION['usuario_id'])) {
            echo json_encode(['success' => false, 'message' => 'Debes iniciar sesión']);
            return;
        }
        
        $perfilId = $_POST['perfil_id'] ?? null;
        
        if ($perfilId) {
            $chatId = $this->chatModel->createChat($perfilId);
            
            if ($chatId) {
                echo json_encode([
                    'success' => true,
                    'chat_id' => $chatId,
                    'message' => 'Nuevo chat creado exitosamente'
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Error al crear el chat en la base de datos'
                ]);
            }
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'No se especificó el perfil'
            ]);
        }
    }
    public function deleteChat() {
        header('Content-Type: application/json');
        
        if (!isset($_SESSION['usuario_id'])) {
            echo json_encode(['success' => false, 'message' => 'No logueado']);
            return;
        }
        
        $chatId = $_POST['chat_id'] ?? null;
        
        if ($chatId) {
            try {
                // ⭐⭐ INICIALIZAR LA CONEXIÓN A LA BASE DE DATOS
                if (!$this->db) {
                    $database = new Database();
                    $this->db = $database->getConnection();
                }
                
                // Primero eliminar los mensajes del chat (por la foreign key)
                $queryMensajes = "DELETE FROM mensajes WHERE chat_id = :chat_id";
                $stmtMensajes = $this->db->prepare($queryMensajes);
                $stmtMensajes->execute([':chat_id' => $chatId]);
                
                // Luego eliminar el chat
                $queryChat = "DELETE FROM chats WHERE id = :chat_id AND usuario_id = :usuario_id";
                $stmtChat = $this->db->prepare($queryChat);
                $result = $stmtChat->execute([
                    ':chat_id' => $chatId,
                    ':usuario_id' => $_SESSION['usuario_id']
                ]);
                
                if ($result && $stmtChat->rowCount() > 0) {
                    echo json_encode([
                        'success' => true, 
                        'message' => 'Chat eliminado exitosamente'
                    ]);
                } else {
                    echo json_encode([
                        'success' => false, 
                        'message' => 'Chat no encontrado o no tienes permisos'
                    ]);
                }
                
            } catch (Exception $e) {
                echo json_encode([
                    'success' => false, 
                    'message' => 'Error al eliminar el chat: ' . $e->getMessage()
                ]);
            }
        } else {
            echo json_encode([
                'success' => false, 
                'message' => 'ID de chat no especificado'
            ]);
        }
    }
    private function eliminarMensajesChat($chatId) {
        try {
            $query = "DELETE FROM mensajes WHERE chat_id = :chat_id";
            $stmt = $this->db->prepare($query);
            return $stmt->execute([':chat_id' => $chatId]);
        } catch (PDOException $e) {
            error_log("Error eliminando mensajes: " . $e->getMessage());
            return false;
        }
    }
    public function renameChat() {
        header('Content-Type: application/json');
        
        if (!isset($_SESSION['usuario_id'])) {
            echo json_encode(['success' => false, 'message' => 'No logueado']);
            return;
        }
        
        $chatId = $_POST['chat_id'] ?? null;
        $nuevoNombre = trim($_POST['nuevo_nombre'] ?? '');
        
        if ($chatId && $nuevoNombre) {
            try {
                // ⭐⭐ INICIALIZAR LA CONEXIÓN A LA BASE DE DATOS
                if (!$this->db) {
                    $database = new Database();
                    $this->db = $database->getConnection();
                }
                
                // Verificar que el chat pertenece al usuario
                $queryVerify = "SELECT id FROM chats WHERE id = :chat_id AND usuario_id = :usuario_id";
                $stmtVerify = $this->db->prepare($queryVerify);
                $stmtVerify->execute([
                    ':chat_id' => $chatId,
                    ':usuario_id' => $_SESSION['usuario_id']
                ]);
                
                if ($stmtVerify->fetch()) {
                    // Actualizar nombre del chat
                    $query = "UPDATE chats SET nombre_chat = :nombre_chat WHERE id = :chat_id";
                    $stmt = $this->db->prepare($query);
                    $result = $stmt->execute([
                        ':nombre_chat' => $nuevoNombre,
                        ':chat_id' => $chatId
                    ]);
                    
                    if ($result) {
                        echo json_encode([
                            'success' => true, 
                            'message' => 'Chat renombrado exitosamente'
                        ]);
                    } else {
                        echo json_encode([
                            'success' => false, 
                            'message' => 'Error al renombrar el chat'
                        ]);
                    }
                } else {
                    echo json_encode([
                        'success' => false, 
                        'message' => 'Chat no encontrado o no tienes permisos'
                    ]);
                }
                
            } catch (Exception $e) {
                echo json_encode([
                    'success' => false, 
                    'message' => 'Error al renombrar el chat: ' . $e->getMessage()
                ]);
            }
        } else {
            echo json_encode([
                'success' => false, 
                'message' => 'Datos incompletos'
            ]);
        }
    }
}

?>